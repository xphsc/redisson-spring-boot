/*
 * Copyright (c) 2023 huipei.x
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package cn.xphsc.redisson.core.bloomfilter;

import cn.xphsc.redisson.annotation.BloomFilter;
import org.redisson.api.RBloomFilter;
import org.redisson.api.RedissonClient;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * {@link }
 * @author <a href="xiongpeih@163.com">huipei.x</a>
 * @description:
 * @since 1.0.3
 */
public class BloomFilterAnnotationProcessor  implements ApplicationContextAware, InitializingBean {

    private ApplicationContext applicationContext;

    private RedissonClient redissonClient;

    private Map<String, RBloomFilter<Object>> bloomFilterMap = new ConcurrentHashMap<>();

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        redissonClient = applicationContext.getBean(RedissonClient.class);
        Map<String, Object> bloomFilters = applicationContext.getBeansWithAnnotation(BloomFilter.class);
        for (Object bean : bloomFilters.values()) {
            processBloomFilter(bean);
        }
    }

    private void processBloomFilter(Object bean) {
        Class<?> clazz = bean.getClass();
        for (Field field : clazz.getDeclaredFields()) {
            BloomFilter annotation = field.getAnnotation(BloomFilter.class);
            if (annotation != null) {
                String name = annotation.name();
                double falseProbability = annotation.falseProbability();
                int expectedElements = annotation.expectedElements();
                RBloomFilter<Object> bloomFilter = redissonClient.getBloomFilter(name);
                bloomFilter.tryInit(expectedElements, falseProbability);
                try {
                    field.setAccessible(true);
                    field.set(bean, bloomFilter);
                    bloomFilterMap.put(name, bloomFilter);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

}
